$('.carousel').carousel();

document.querySelector('.toggleClass').onclick = function(){
    document.querySelector('.theTitle').classList.toggle('active');
};


